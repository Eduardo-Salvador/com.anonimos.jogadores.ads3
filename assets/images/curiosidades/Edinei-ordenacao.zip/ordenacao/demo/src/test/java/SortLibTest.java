import org.junit.jupiter.api.Test;

import com.example.Pessoa;
import com.example.SortLib;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Locale;
import java.util.Random;

public class SortLibTest { 

    private static final int[] TAMANHOS = {100, 1000, 50000};
    private static final Random RANDOM = new Random(42); // seed fixa = resultados reproduzíveis

    private Pessoa[] gerarPessoas(int tamanho) {
        Pessoa[] pessoas = new Pessoa[tamanho];
        for (int i = 0; i < tamanho; i++) {
            double salario = 1_000.0 + (RANDOM.nextDouble() * 9_000.0);
            pessoas[i] = new Pessoa("Pessoa" + i, salario);
        }
        return pessoas;
    }

    private boolean isOrdenado(Pessoa[] pessoas) {
        for (int i = 0; i < pessoas.length - 1; i++) {
            if (pessoas[i].getSalario() > pessoas[i + 1].getSalario()) {
                return false;
            }
        }
        return true;
    }

    @Test
    public void testCompararAlgoritmos() {
        for (int tamanho : TAMANHOS) {

            Pessoa[] vetorBase = gerarPessoas(tamanho);
       
            Pessoa[] destinoSelection = clonarVetor(vetorBase);
            long inicioSelection = System.nanoTime();
            SortLib.selectionSort(destinoSelection, tamanho);
            long fimSelection = System.nanoTime();
            assertTrue(isOrdenado(destinoSelection), "SelectionSort falhou para " + tamanho + " elementos.");
            imprimirResultado("SelectionSort", tamanho, inicioSelection, fimSelection);

            Pessoa[] destinoBubble = clonarVetor(vetorBase);
            long inicioBubble = System.nanoTime();
            SortLib.bubbleSort(destinoBubble, tamanho);
            long fimBubble = System.nanoTime();
            assertTrue(isOrdenado(destinoBubble), "BubbleSort falhou para " + tamanho + " elementos.");
            imprimirResultado("BubbleSort", tamanho, inicioBubble, fimBubble);

            Pessoa[] destinoInsertion = clonarVetor(vetorBase);
            long inicioInsertion = System.nanoTime();
            SortLib.insertionSort(destinoInsertion, tamanho);
            long fimInsertion = System.nanoTime();
            assertTrue(isOrdenado(destinoInsertion), "InsertionSort falhou para " + tamanho + " elementos.");
            imprimirResultado("InsertionSort", tamanho, inicioInsertion, fimInsertion);
        }
    }

    private Pessoa[] clonarVetor(Pessoa[] original) {
        Pessoa[] copia = new Pessoa[original.length];
        System.arraycopy(original, 0, copia, 0, original.length);
        return copia;
    }

    private void imprimirResultado(String algoritmo, int tamanho, long inicio, long fim) {
        double milissegundos = (fim - inicio) / 1_000_000.0;
        Locale localeBR = new Locale("pt", "BR");
        System.out.printf(localeBR, "%s com %d elementos: %.2f ms%n%n", algoritmo, tamanho, milissegundos);
    }
}

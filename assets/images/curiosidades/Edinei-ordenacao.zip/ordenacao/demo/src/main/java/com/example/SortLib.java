package com.example;

public class SortLib {

	public static void insertionSort(Pessoa[] pessoas, int quantidadeElementos) {

		validarEntrada(pessoas, quantidadeElementos);

		for (int posicaoAtual = 1; posicaoAtual < quantidadeElementos; posicaoAtual++) {
			int posAnalise = posicaoAtual;
			while (posAnalise > 0 && pessoas[posAnalise].getSalario() < pessoas[posAnalise - 1].getSalario()) {
				trocar(pessoas, posAnalise, posAnalise - 1);
				posAnalise--;
			}
		}

	}

	public static void bubbleSort(Pessoa[] pessoas, int quantidadeElementos) {

		validarEntrada(pessoas, quantidadeElementos);

		for (int i = 0; i < quantidadeElementos - 1; i++) {
			boolean trocou = false;
			for (int j = 0; j < quantidadeElementos - 1 - i; j++) {
				if (pessoas[j].getSalario() > pessoas[j + 1].getSalario()) {
					trocar(pessoas, j, j + 1);
					trocou = true;
				}
			}
			if (!trocou) {
				break;
			}
		}

	}

	public static void selectionSort(Pessoa[] pessoas, int quantidadeElementos) {

		validarEntrada(pessoas, quantidadeElementos);

		for (int posicaoAtual = 0; posicaoAtual < quantidadeElementos - 1; posicaoAtual++) {
			int posicaoMenor = buscaMenorSalario(pessoas, posicaoAtual, quantidadeElementos - 1);
			trocar(pessoas, posicaoAtual, posicaoMenor);
		}

	}
	private static void trocar(Pessoa[] pessoas, int posicaoPrimeiro, int posicaoSegundo) {

		Pessoa temp = pessoas[posicaoPrimeiro];
		pessoas[posicaoPrimeiro] = pessoas[posicaoSegundo];
		pessoas[posicaoSegundo] = temp;

	}

	private static int buscaMenorSalario(Pessoa[] pessoas, int posicaoInicio, int posicaoTermino) {

		int posicaoMenorSalario = posicaoInicio;

		for (int posicaoAtual = posicaoInicio + 1; posicaoAtual <= posicaoTermino; posicaoAtual++) {

			if (pessoas[posicaoAtual].getSalario() < pessoas[posicaoMenorSalario].getSalario()) {
				posicaoMenorSalario = posicaoAtual;
			}
		}
		return posicaoMenorSalario;
	}

	private static void validarEntrada(Pessoa[] pessoas, int quantidadeElementos) {
		if (pessoas == null) {
			throw new IllegalArgumentException("Array de pessoas não pode ser nulo");
		}
		if (quantidadeElementos < 0) {
			throw new IllegalArgumentException("Quantidade de elementos inválida: " + quantidadeElementos);
		}
		for (int i = 0; i < quantidadeElementos; i++) {
			if (pessoas[i] == null) {
				throw new IllegalArgumentException("Elemento nulo na posição: " + i);
			}
		}
	}

}